%% Computes a functional representation of a given pointwise map
% in the reduced (LB eigenfunction) basis.
clearvars;
close all;
clc;

addpath('utils/');
addpath('shapes/');

source_shape = 'tr_reg_089.off';
target_shape = 'tr_reg_090.off';

S1 = read_off_shape(source_shape);
S2 = read_off_shape(target_shape);

fprintf('Read the source shape with %d vertices\n', S1.surface.nv);
fprintf('Read the target shape with %d vertices\n', S2.surface.nv);

% Number of functions to use in the reduced basis.
lb_k = 30;

fprintf('computing the basis with %d eigenpairs...', lb_k);tic;
L1  = lb_basis_surface(S1, lb_k);
L2  = lb_basis_surface(S2, lb_k);
fprintf('done\n'); toc;

% The permutation matrix encoding the point-to-point map,
% which is identity for this shape pair.
P = speye(S1.surface.nv);

% The functional map representation.
fprintf('computing the fmap...');
C = L2.evecs'*L2.A'*P'*L1.evecs;
fprintf('done\n');toc;

imagesc(C);
title('Functional representation of the point-to-point map','Fontsize',16);
xlabel('Basis on the source','FontSize',20);
ylabel('Basis on the target','FontSize',20);