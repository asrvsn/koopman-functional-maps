function errs = compute_euclidean_errors(S1, map)
    E1 = [S1.surface.X S1.surface.Y S1.surface.Z];

    errs = sqrt(sum((E1-E1(map,:)).^2,2));
end