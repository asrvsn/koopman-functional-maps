function [S1, L1, S2, L2, C] = compute_fmap(source_shape, target_shape, lb_k)
    S1 = read_off_shape(source_shape);
    S2 = read_off_shape(target_shape);

    L1  = lb_basis_surface(S1, lb_k);
    L2  = lb_basis_surface(S2, lb_k);
    
    % Check that the basis is orthonormal with respect to the area matrix.
    assert(norm(L2.evecs'*L2.A*L2.evecs - eye(lb_k,lb_k),'fro')<1e-7);

    % The functional map representation.
    C = L2.evecs'*L2.A*L1.evecs;
end