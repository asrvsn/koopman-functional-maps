function area = surface_area(surface)
    X = [surface.X surface.Y surface.Z];
    T = surface.TRIV;
    
    % areas of triangles
    N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
    At = 1/2*normv(N);

    area = sum(At);
end