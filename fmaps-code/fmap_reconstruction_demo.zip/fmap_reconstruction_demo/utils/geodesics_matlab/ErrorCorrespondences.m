function h = ErrorCorrespondences(X, T, pi, piEx,  areas, Sym)

totalArea = sum(areas);

if exist('Sym', 'var')
    symmetry = true;
else
    symmetry = false;
end

pairs = [pi, piEx];

surface.X = X(:,1);
surface.Y = X(:,2);
surface.Z = X(:,3);
surface.TRIV = T;

dist = dijkstra_pairs(surface, pairs);
if (symmetry == true)
    dist = min(dist, dijkstra_pairs(surface, [pi, Sym(piEx)]));
end

dist = dist/sqrt(totalArea);

dsort = sort(dist);
cdf = zeros(length(dist), 1);
for i = 1:length(dist)
    cdf(i) = sum(dist <= dsort(i));
end
cdf = cdf/length(dist);

h = plot(sort(dist), cdf);
set(h,'linewidth',3);
grid on;