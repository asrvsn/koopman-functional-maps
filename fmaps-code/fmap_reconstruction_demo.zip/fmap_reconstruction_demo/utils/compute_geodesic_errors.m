function errs = compute_geodesic_errors(S1, map, nsamples)
    addpath('utils/geodesics_matlab/');
    % Compute a set of points using farthest point sampling
    samples = dijkstra_fps(S1, nsamples);
    
    % Compute the distances between the ground truth map and the given one.
    errs = dijkstra_pairs(S1.surface, [samples map(samples)]);
end