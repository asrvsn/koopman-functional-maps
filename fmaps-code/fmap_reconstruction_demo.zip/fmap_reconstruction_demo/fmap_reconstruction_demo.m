clearvars;
close all;
clc;

addpath('utils/');
addpath('shapes/');

source_shape = 'tr_reg_089.off';
target_shape = 'tr_reg_090.off';

% Number of functions to use in the reduced basis.
lb_k = 100;

% Compute the functional map assuming the identity point-to-point map.
% Outputs the shapes S1, S2, their eigenbases L1, L2 and the functional 
% map C which will be a matrix of size lb_k x lb_k.
[S1, L1, S2, L2, C] = compute_fmap(source_shape, target_shape, lb_k);

%%
% Compute the images of all the delta functions in the reduced basis
% We use the rows of LB eigenfunction, which corresponds to the heat
% kernels at every point for an infinitesimal time t. Alternatively, one
% can also use (L1.evecs'*L1.A) and L2.evecs'*L2.A to recover images of
% indicator functions at vertices.
X = C*(L1.evecs');
Y = L2.evecs';

% Find nearest neighbors between the mapped delta functions and 
% the ones of the target shape. This gives us a point-to-point map from the
% target shape to the source shape.
map = knnsearch(X', Y');

%%
% Compute Euclidean distances between the ground truth correspondence and 
% the computed ones.
errs = compute_euclidean_errors(S1, map);

% Compute geodesic distances between a subsample of ground truth 
% correspondence and  the computed ones. Slower but might be more accurate
% in the presence of large errors.
% errs = compute_geodesic_errors(S1, map, 300);

 %%
figure(1);
plot(sort(errs)/S1.surface.area, linspace(0,1,length(errs)));

xlabel('Distance error threshold','FontSize',20);
ylabel('Fraction of correspondences','FontSize',20);
title('Point-to-point map reconstruction error','FontSize',20);

axis([0 0.1 0 1]);