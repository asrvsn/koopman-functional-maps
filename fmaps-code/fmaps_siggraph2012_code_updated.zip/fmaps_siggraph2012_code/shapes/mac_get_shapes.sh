curl -O http://graphics.stanford.edu/~maks/shapes/cat0_cot.mat
curl -O http://graphics.stanford.edu/~maks/shapes/cat0.mat
curl -O http://graphics.stanford.edu/~maks/shapes/cat10_cot.mat
curl -O http://graphics.stanford.edu/~maks/shapes/cat10.mat