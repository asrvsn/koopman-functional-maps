wget http://graphics.stanford.edu/~maks/shapes/cat0_cot.mat
wget http://graphics.stanford.edu/~maks/shapes/cat0.mat
wget http://graphics.stanford.edu/~maks/shapes/cat10_cot.mat
wget http://graphics.stanford.edu/~maks/shapes/cat10.mat