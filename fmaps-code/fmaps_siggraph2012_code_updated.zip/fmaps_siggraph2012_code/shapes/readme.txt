Download shapes from http://graphics.stanford.edu/~maks/shapes/

To get started with a simple example, simply run ./linux_get_shapes.sh or ./mac_get_shapes.sh depending on your platform.

Please don't check the shapes files into the svn, since each .mat file is about 62M

All shapes + segmentations are also available at: http://graphics.stanford.edu/~mirela/shapes.zip