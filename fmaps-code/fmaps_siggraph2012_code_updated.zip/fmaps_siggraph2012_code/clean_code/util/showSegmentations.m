close all
showSegmentation(mesh1, segMethod); 
showSegmentation(mesh2, segMethod);
